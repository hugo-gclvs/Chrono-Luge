# ADC_Read_Voltage_Simple
Basic ADC example read voltage.

# ADC_Read_Voltage_Accurate
A function that improves the defaulot ADC reading accuracy to within 1%
